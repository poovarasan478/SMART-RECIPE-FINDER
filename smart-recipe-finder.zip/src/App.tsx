import React, { useState, useEffect } from "react";
import { 
  ChefHat, 
  Moon, 
  Sun, 
  Heart, 
  Filter, 
  Sparkles, 
  Search, 
  History, 
  BookOpen, 
  Trash2, 
  AlertTriangle 
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

import { Meal, DetailedMeal, Category } from "./types";
import SearchBar from "./components/SearchBar";
import RecipeCard from "./components/RecipeCard";
import RecipeDetails from "./components/RecipeDetails";

const POPULAR_INGREDIENTS = [
  "Chicken", "Beef", "Tomato", "Cheese", "Pasta", "Potato", "Lemon", "Rice"
];

// Predefined categories in case of offline / API delay (used as fallback or labels)
const DEFAULT_CATEGORIES = [
  "Beef", "Chicken", "Dessert", "Lamb", "Miscellaneous", "Pasta", "Pork", 
  "Seafood", "Side", "Starter", "Vegan", "Vegetarian", "Breakfast", "Goat"
];

export default function App() {
  // --- UI and Theme states ---
  const [isDark, setIsDark] = useState<boolean>(() => {
    // Check localStorage or system preference
    if (typeof window !== "undefined") {
      const savedTheme = localStorage.getItem("theme");
      if (savedTheme) return savedTheme === "dark";
      return window.matchMedia("(prefers-color-scheme: dark)").matches;
    }
    return false;
  });

  // --- Core Recipe States ---
  const [recipes, setRecipes] = useState<Meal[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>(""); // "" means home/ingredient search
  const [searchQuery, setSearchQuery] = useState<string>("Chicken"); // Initial default search
  const [searchHistory, setSearchHistory] = useState<string[]>(() => {
    if (typeof window !== "undefined") {
      const savedHist = localStorage.getItem("search_history");
      return savedHist ? JSON.parse(savedHist) : ["Chicken", "Tomato"];
    }
    return ["Chicken", "Tomato"];
  });

  // --- Favorite Recipes States ---
  const [favorites, setFavorites] = useState<Meal[]>(() => {
    if (typeof window !== "undefined") {
      const savedFavs = localStorage.getItem("favorites");
      return savedFavs ? JSON.parse(savedFavs) : [];
    }
    return [];
  });

  // View Mode: 'browse' / 'favorites'
  const [viewMode, setViewMode] = useState<"browse" | "favorites">("browse");

  // --- Local Filtering State (allows user to filter fetched results directly) ---
  const [localFilter, setLocalFilter] = useState<string>("");

  // --- API status states ---
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isLoadingCategories, setIsLoadingCategories] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  // --- Modal State ---
  const [selectedMealId, setSelectedMealId] = useState<string | null>(null);
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);

  // --- HTML Class Theme Effect ---
  useEffect(() => {
    const root = window.document.documentElement;
    if (isDark) {
      root.classList.add("dark");
      localStorage.setItem("theme", "dark");
    } else {
      root.classList.remove("dark");
      localStorage.setItem("theme", "light");
    }
  }, [isDark]);

  // --- Sync storage ---
  useEffect(() => {
    localStorage.setItem("favorites", JSON.stringify(favorites));
  }, [favorites]);

  useEffect(() => {
    localStorage.setItem("search_history", JSON.stringify(searchHistory));
  }, [searchHistory]);

  // --- Fetch categories list on mount ---
  useEffect(() => {
    const fetchCategories = async () => {
      setIsLoadingCategories(true);
      try {
        const res = await fetch("https://www.themealdb.com/api/json/v1/1/categories.php");
        const data = await res.json();
        if (data && data.categories) {
          setCategories(data.categories);
        }
      } catch (err) {
        console.error("Failed to load MealDB categories: ", err);
      } finally {
        setIsLoadingCategories(false);
      }
    };
    fetchCategories();
  }, []);

  // --- Initial search on mount ---
  useEffect(() => {
    handleSearchByIngredient(searchQuery, false);
  }, []);

  // --- Fetch detailed recipe info for cards ---
  // To display category / area directly on the cards, we can resolve them in batches
  const enrichMealsWithDetails = async (mealsList: Meal[]) => {
    // Limit enriching to the first 24 meals for quick UI rendering and avoiding rate-limiting
    const mealsToEnrich = mealsList.slice(0, 24);
    
    try {
      const enriched = await Promise.all(
        mealsToEnrich.map(async (m) => {
          try {
            const res = await fetch(`https://www.themealdb.com/api/json/v1/1/lookup.php?i=${m.idMeal}`);
            const data = await res.json();
            if (data && data.meals && data.meals.length > 0) {
              const details = data.meals[0];
              return {
                ...m,
                strCategory: details.strCategory,
                strArea: details.strArea,
              };
            }
          } catch (e) {
            console.error(`Error enriching meal details for ${m.idMeal}`, e);
          }
          return m;
        })
      );

      // Pad remaining items if any
      const remaining = mealsList.slice(24);
      setRecipes([...enriched, ...remaining]);
    } catch (err) {
      console.error("Batch details loader exception", err);
    }
  };

  // --- Main Fetch API Handlers ---
  const handleSearchByIngredient = async (ingredient: string, updateHistory: boolean = true) => {
    if (!ingredient.trim()) return;
    
    setIsLoading(true);
    setError(null);
    setSelectedCategory(""); // Reset category filter when doing specific search
    setViewMode("browse");
    setLocalFilter(""); // Clear secondary local filter
    
    try {
      const formattedIngredient = ingredient.trim().toLowerCase().replace(/\s+/g, "_");
      const url = `https://www.themealdb.com/api/json/v1/1/filter.php?i=${formattedIngredient}`;
      const response = await fetch(url);
      const data = await response.json();
      
      if (data && data.meals) {
        // Enriched status placeholder to start displaying instantly
        setRecipes(data.meals);
        
        // Add to search history if success
        if (updateHistory) {
          setSearchHistory((prev) => {
            const filtered = prev.filter((item) => item.toLowerCase() !== ingredient.trim().toLowerCase());
            return [ingredient.trim(), ...filtered].slice(0, 8); // Keep last 8 searches
          });
        }
        
        // Asynchronous enrichment for gorgeous cards (category/area badges)
        enrichMealsWithDetails(data.meals);
      } else {
        setRecipes([]);
      }
    } catch (err) {
      console.error("Error searching recipes:", err);
      setError("An error occurred while fetching recipe data. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleCategorySelect = async (categoryName: string) => {
    setIsLoading(true);
    setError(null);
    setSelectedCategory(categoryName);
    setSearchQuery(""); // Reset search query string
    setViewMode("browse");
    setLocalFilter(""); // Clear secondary local filter

    try {
      const url = `https://www.themealdb.com/api/json/v1/1/filter.php?c=${categoryName}`;
      const response = await fetch(url);
      const data = await response.json();

      if (data && data.meals) {
        // Enforce state & async details fetching
        setRecipes(data.meals);
        enrichMealsWithDetails(data.meals);
      } else {
        setRecipes([]);
      }
    } catch (err) {
      console.error("Error fetching recipes by category:", err);
      setError("Failed to fetch recipes for this category.");
    } finally {
      setIsLoading(false);
    }
  };

  // --- Search Submission handler ---
  const handleFormSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      handleSearchByIngredient(searchQuery, true);
    }
  };

  // --- History Interaction ---
  const handleSelectHistory = (item: string) => {
    setSearchQuery(item);
    handleSearchByIngredient(item, true);
  };

  const handleClearHistory = () => {
    setSearchHistory([]);
  };

  // --- Favorites Management ---
  const handleToggleFavorite = (meal: Meal) => {
    setFavorites((prev) => {
      const exists = prev.some((item) => item.idMeal === meal.idMeal);
      if (exists) {
        return prev.filter((item) => item.idMeal !== meal.idMeal);
      } else {
        return [...prev, meal];
      }
    });
  };

  // --- Modal Open ---
  const handleViewDetails = (meal: Meal) => {
    setSelectedMealId(meal.idMeal);
    setIsModalOpen(true);
  };

  // --- Local filter of currently loaded recipes ---
  const getFilteredRecipes = () => {
    const listToFilter = viewMode === "favorites" ? favorites : recipes;
    if (!localFilter.trim()) return listToFilter;

    const term = localFilter.toLowerCase();
    return listToFilter.filter((m) => {
      const nameMatch = m.strMeal.toLowerCase().includes(term);
      const categoryMatch = m.strCategory?.toLowerCase().includes(term);
      const cuisineMatch = m.strArea?.toLowerCase().includes(term);
      return nameMatch || categoryMatch || cuisineMatch;
    });
  };

  const filteredList = getFilteredRecipes();

  return (
    <div className={`min-h-screen transition-colors duration-300 flex flex-col ${
      isDark ? "bg-gray-950 text-gray-100" : "bg-orange-50/20 text-gray-900"
    }`} id="smart-recipe-finder-app">
      
      {/* Decorative top header / brand bar */}
      <header className="sticky top-0 z-40 bg-white/80 dark:bg-gray-950/80 backdrop-blur-md border-b border-gray-100 dark:border-gray-900 transition-colors duration-300">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between" id="app-header-inner">
          
          {/* Logo Brand */}
          <div className="flex items-center gap-2.5 cursor-pointer select-none" onClick={() => {
            setSearchQuery("Chicken");
            handleSearchByIngredient("Chicken", false);
          }} id="brand-logo">
            <div className="p-2.5 bg-gradient-to-br from-orange-500 to-rose-500 text-white rounded-2xl shadow-md shadow-orange-500/20">
              <ChefHat className="w-5 h-5 md:w-6 h-6 animate-bounce" style={{ animationDuration: '3s' }} />
            </div>
            <div>
              <h1 className="font-sans font-extrabold text-lg md:text-xl tracking-tight bg-gradient-to-r from-orange-500 via-rose-500 to-red-600 bg-clip-text text-transparent">
                Smart Recipe Finder
              </h1>
              <p className="text-[10px] md:text-xs font-semibold text-gray-400 dark:text-gray-500 tracking-wider uppercase">
                College Project Edition
              </p>
            </div>
          </div>

          {/* Header Action menu */}
          <div className="flex items-center gap-2 md:gap-4" id="header-actions">
            
            {/* View Mode Favorite Toggle */}
            <button
              onClick={() => {
                setViewMode(viewMode === "browse" ? "favorites" : "browse");
              }}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs md:text-sm font-semibold transition-all shadow-sm ${
                viewMode === "favorites"
                  ? "bg-rose-500 text-white hover:bg-rose-600 shadow-rose-200 dark:shadow-none"
                  : "bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-755"
              }`}
              id="header-favs-view-toggle"
            >
              <Heart className={`w-4 h-4 ${viewMode === "favorites" ? "fill-current" : ""}`} />
              <span className="hidden sm:inline">Favorites</span>
              <span className="px-1.5 py-0.5 rounded-full bg-black/10 dark:bg-white/10 text-[10px] font-bold">
                {favorites.length}
              </span>
            </button>

            {/* Dark Mode toggle */}
            <button
              onClick={() => setIsDark(!isDark)}
              className="p-2.5 rounded-xl bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-300 transition-colors"
              aria-label="Toggle visual theme"
              id="theme-toggler"
            >
              {isDark ? <Sun className="w-4 h-4 md:w-5 h-5 text-amber-400" /> : <Moon className="w-4 h-4 md:w-5 h-5" />}
            </button>
          </div>
        </div>
      </header>

      {/* Hero Banner Section */}
      <section className="relative overflow-hidden bg-gradient-to-b from-orange-100/40 via-transparent to-transparent dark:from-orange-950/10 dark:via-transparent dark:to-transparent py-10 md:py-16 px-4 text-center border-b border-gray-100/40 dark:border-gray-900/40" id="hero-banner">
        <div className="max-w-4xl mx-auto flex flex-col gap-4">
          <div className="inline-flex items-center gap-1.5 self-center px-3.5 py-1.5 rounded-full bg-orange-500/10 dark:bg-orange-500/20 border border-orange-500/20 text-orange-600 dark:text-orange-400 text-xs font-semibold uppercase tracking-wider">
            <Sparkles className="w-3.5 h-3.5 animate-pulse" /> Find Recipes Dynamic by Ingredient
          </div>
          <h2 className="font-display font-extrabold text-3xl md:text-5xl lg:text-6xl text-gray-900 dark:text-white leading-tight">
            What's inside your <span className="bg-gradient-to-r from-orange-500 to-rose-500 bg-clip-text text-transparent">pantry?</span>
          </h2>
          <p className="text-sm md:text-base text-gray-500 dark:text-gray-400 max-w-xl mx-auto leading-relaxed">
            Specify ingredients you have, or choose a category below. We'll search delicious recipes and display measurements, directions, and video cooking instructions automatically.
          </p>

          {/* Search Bar Integration */}
          <div className="mt-6">
            <SearchBar
              query={searchQuery}
              setQuery={setSearchQuery}
              onSearch={handleFormSearch}
              isLoading={isLoading}
              history={searchHistory}
              onSelectHistory={handleSelectHistory}
              onClearHistory={handleClearHistory}
              popularIngredients={POPULAR_INGREDIENTS}
            />
          </div>
        </div>

        {/* Ambient Glowing Background Blobs */}
        <div className="absolute top-1/2 left-0 -translate-y-1/2 w-48 h-48 bg-orange-400/10 dark:bg-orange-500/5 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute top-1/2 right-0 -translate-y-1/2 w-48 h-48 bg-rose-400/10 dark:bg-rose-500/5 rounded-full blur-3xl pointer-events-none" />
      </section>

      {/* Main Panel Content */}
      <main className="flex-grow max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-8 flex flex-col gap-8">
        
        {/* Category Pills Container */}
        <section id="category-scroller">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-xs font-bold text-gray-400 dark:text-gray-500 uppercase tracking-widest flex items-center gap-1">
              <Filter className="w-3 text-orange-500" /> Explore Recipes By Food Category
            </h3>
            {selectedCategory && (
              <button
                onClick={() => {
                  setSearchQuery("Chicken");
                  handleSearchByIngredient("Chicken", false);
                }}
                className="text-xs text-orange-500 hover:underline"
                id="reset-category-pill"
              >
                Reset Filter
              </button>
            )}
          </div>

          <div className="flex gap-2.5 overflow-x-auto pb-3 mask-gradient" id="category-pills">
            {/* "All Search" Pill */}
            <button
              onClick={() => {
                setSearchQuery("Chicken");
                handleSearchByIngredient("Chicken", false);
              }}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs md:text-sm font-semibold border whitespace-nowrap transition-all scroll-snap-align ${
                !selectedCategory && viewMode === "browse"
                  ? "bg-orange-500 border-orange-500 text-white shadow-md shadow-orange-500/10"
                  : "bg-white dark:bg-gray-800 border-gray-250 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600 text-gray-700 dark:text-gray-300"
              }`}
              id="category-search-pill"
            >
              <Search className="w-4 h-4" /> Ingredient Search
            </button>

            {isLoadingCategories ? (
              // Loading placeholders for categories
              DEFAULT_CATEGORIES.map((c, idx) => (
                <div key={idx} className="w-24 h-9 bg-gray-200 dark:bg-gray-800 animate-pulse rounded-xl" />
              ))
            ) : (
              categories.map((cat) => {
                const isCatSelected = selectedCategory === cat.strCategory && viewMode === "browse";
                return (
                  <button
                    key={cat.idCategory}
                    onClick={() => handleCategorySelect(cat.strCategory)}
                    className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs md:text-sm font-semibold border whitespace-nowrap transition-all cursor-pointer ${
                      isCatSelected
                        ? "bg-orange-500 border-orange-500 text-white shadow-md shadow-orange-500/10"
                        : "bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600 text-gray-700 dark:text-gray-300"
                    }`}
                    id={`category-pill-${cat.strCategory.toLowerCase()}`}
                  >
                    <img
                      src={cat.strCategoryThumb}
                      alt={cat.strCategory}
                      className="w-5 h-5 object-contain opacity-90 group-hover:opacity-100"
                      referrerPolicy="no-referrer"
                    />
                    {cat.strCategory}
                  </button>
                );
              })
            )}
          </div>
        </section>

        {/* Secondary Input: Results Count & Local Filtering of Recipes */}
        <section className="bg-white dark:bg-gray-900 border border-gray-150 dark:border-gray-800 rounded-2xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-sm" id="results-dashboard-bar">
          <div className="flex items-center gap-2" id="results-headline">
            <BookOpen className="w-5 h-5 text-orange-500" />
            <div>
              <p className="text-sm font-bold text-gray-800 dark:text-gray-200">
                {viewMode === "favorites" ? "Bookmarks & Saved Recipes" : "Database Search Results"}
              </p>
              <p className="text-xs text-gray-400">
                {isLoading ? "Searching meal registry..." : `Showing ${filteredList.length} unique recipes`}
              </p>
            </div>
          </div>

          {/* Search Result Inner-Filter input */}
          <div className="relative flex-1 max-w-md w-full" id="local-results-filter">
            <div className="absolute inset-y-0 left-3 flex items-center pointer-events-none text-gray-400">
              <Filter className="w-4 h-4" />
            </div>
            <input
              id="local-filter-input"
              type="text"
              value={localFilter}
              onChange={(e) => setLocalFilter(e.target.value)}
              placeholder="Filter these recipes by title, country or tag..."
              className="w-full pl-9 pr-8 py-2 border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 text-gray-900 dark:text-gray-100 placeholder-gray-400 text-xs md:text-sm rounded-xl focus:outline-none focus:ring-1 focus:ring-orange-500 focus:bg-white dark:focus:bg-gray-800 transition-all font-sans"
            />
            {localFilter && (
              <button
                onClick={() => setLocalFilter("")}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 transition-colors"
                id="clear-local-filter"
              >
                Clear
              </button>
            )}
          </div>
        </section>

        {/* Recipe Cards Stage */}
        <section id="recipe-cards-stage">
          {isLoading ? (
            // Modern Animated Loading Platter
            <div className="flex flex-col items-center justify-center py-24 text-center gap-4" id="main-spinner">
              <div className="relative w-24 h-24">
                {/* Outermost Ring */}
                <div className="absolute inset-0 rounded-full border-4 border-orange-500/10 border-t-orange-500 border-r-orange-500 animate-spin" style={{ animationDuration: '0.8s' }} />
                {/* Innermost pulsing background */}
                <div className="absolute inset-3 bg-gradient-to-br from-orange-400/20 to-rose-400/20 dark:from-orange-500/5 dark:to-rose-500/5 rounded-full flex items-center justify-center animate-pulse-slow">
                  <ChefHat className="w-8 h-8 text-orange-500" />
                </div>
              </div>
              <div>
                <h4 className="font-sans font-bold text-lg text-gray-830 dark:text-gray-250">Gourmet Fetching...</h4>
                <p className="text-xs text-gray-400 dark:text-gray-500 max-w-xs mx-auto">Accessing TheMealDB API, sorting fresh ingredients, and formatting recipes.</p>
              </div>
            </div>
          ) : error ? (
            // Full screen Error warning
            <div className="text-center py-20 px-4 bg-red-500/5 dark:bg-red-500/10 border border-red-500/10 rounded-3xl" id="api-error-card">
              <AlertTriangle className="w-12 h-12 text-red-500 dark:text-red-400 mx-auto mb-4" />
              <h3 className="font-sans font-bold text-lg text-red-600 dark:text-red-400">Connection Failed</h3>
              <p className="text-xs text-gray-500 dark:text-gray-400 max-w-sm mx-auto mt-1 leading-relaxed">
                {error}
              </p>
              <button
                onClick={() => handleSearchByIngredient("Chicken", false)}
                className="mt-4 px-5 py-2 text-xs rounded-xl bg-red-630 text-white hover:bg-red-700 transition shadow bg-red-500 hover:bg-red-600"
              >
                Retry Request
              </button>
            </div>
          ) : filteredList.length === 0 ? (
            // Empty Screen
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-center py-20 px-4 bg-white dark:bg-gray-900 border border-gray-150 dark:border-gray-800 rounded-3xl"
              id="no-recipes-panel"
            >
              <div className="w-16 h-16 bg-gray-100 dark:bg-gray-850 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <ChefHat className="w-8 h-8 text-gray-400 dark:text-gray-500" />
              </div>
              <h3 className="font-sans font-bold text-lg text-gray-800 dark:text-white">
                {viewMode === "favorites" ? "No bookmarked favorites" : "No recipes found"}
              </h3>
              <p className="text-xs md:text-sm text-gray-400 dark:text-gray-500 max-w-md mx-auto mt-1.5 leading-relaxed">
                {viewMode === "favorites" 
                  ? "Explore ingredients or browse categories and tap the heart icon on cards to save recipes to your collection."
                  : `We couldn't locate meals matching "${searchQuery || 'this ingredient'}" on the server, or matching "${localFilter}" locally. Try writing basic pantry items like "Chicken", "Beef", "Egg" or "Milk"!`}
              </p>

              {(searchQuery || localFilter || selectedCategory) && (
                <button
                  onClick={() => {
                    setSearchQuery("Chicken");
                    setLocalFilter("");
                    setSelectedCategory("");
                    setViewMode("browse");
                    handleSearchByIngredient("Chicken", false);
                  }}
                  className="mt-6 px-5 py-2.5 text-xs font-semibold rounded-xl bg-orange-500 hover:bg-orange-600 text-white transition-colors"
                  id="reset-pantry-btn"
                >
                  Reset Pantry Shelf
                </button>
              )}
            </motion.div>
          ) : (
            // Cards Grid container
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 md:gap-8" id="recipes-bento-grid">
              <AnimatePresence mode="popLayout">
                {filteredList.map((meal) => {
                  const isFavorite = favorites.some((f) => f.idMeal === meal.idMeal);
                  return (
                    <div key={meal.idMeal} id={`recipe-item-${meal.idMeal}`} className="h-full">
                      <RecipeCard
                        meal={meal}
                        isFavorite={isFavorite}
                        onToggleFavorite={handleToggleFavorite}
                        onViewDetails={handleViewDetails}
                      />
                    </div>
                  );
                })}
              </AnimatePresence>
            </div>
          )}
        </section>
      </main>

      {/* Culinary Recipe Details Modal container */}
      <RecipeDetails
        mealId={selectedMealId}
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setSelectedMealId(null);
        }}
        favorites={favorites}
        onToggleFavorite={handleToggleFavorite}
      />

      {/* Humble Footer with Anti-AI-Slop Styling */}
      <footer className="mt-auto border-t border-gray-100 dark:border-gray-900 bg-white dark:bg-gray-950 transition-colors duration-300">
        <div className="max-w-7xl mx-auto px-4 py-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left" id="footer-inner">
          <div>
            <p className="text-xs md:text-sm font-sans text-gray-500 dark:text-gray-400">
              © 2026 Smart Recipe Finder. Developed for computer engineering college project evaluation.
            </p>
            <p className="text-[10px] text-gray-400 dark:text-gray-500 mt-0.5">
              Powered by <a href="https://www.themealdb.com" target="_blank" rel="noreferrer" className="underline hover:text-orange-500 transition-colors">TheMealDB API</a>
            </p>
          </div>
          <div className="flex items-center gap-1.5" id="developer-credits">
            <span className="text-2xs font-bold text-gray-400 uppercase tracking-widest bg-gray-50 dark:bg-gray-900 p-2 rounded-lg border border-gray-150 dark:border-gray-800">
              Responsive client implementation
            </span>
          </div>
        </div>
      </footer>
    </div>
  );
}
