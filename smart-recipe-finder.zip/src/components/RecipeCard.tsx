import { Heart, ArrowRight } from "lucide-react";
import { Meal } from "../types";
import { motion } from "motion/react";

interface RecipeCardProps {
  meal: Meal;
  isFavorite: boolean;
  onToggleFavorite: (meal: Meal) => void;
  onViewDetails: (meal: Meal) => void;
  isLoadingDetails?: boolean;
}

export default function RecipeCard({
  meal,
  isFavorite,
  onToggleFavorite,
  onViewDetails,
}: RecipeCardProps) {
  // Map category to aesthetic color badge styles
  const getCategoryStyles = (cat?: string) => {
    if (!cat) return "bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-200";
    const c = cat.toLowerCase();
    if (c.includes("vegetarian") || c.includes("vegan")) {
      return "bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300 border-emerald-100 dark:border-emerald-900/30";
    }
    if (c.includes("dessert") || c.includes("sweet")) {
      return "bg-pink-50 text-pink-700 dark:bg-pink-950/40 dark:text-pink-300 border-pink-100 dark:border-pink-900/30";
    }
    if (c.includes("seafood") || c.includes("fish")) {
      return "bg-sky-50 text-sky-700 dark:bg-sky-950/40 dark:text-sky-300 border-sky-100 dark:border-sky-900/30";
    }
    if (c.includes("chicken") || c.includes("poultry")) {
      return "bg-amber-50 text-amber-700 dark:bg-amber-950/40 dark:text-amber-300 border-amber-100 dark:border-amber-900/30";
    }
    if (c.includes("beef") || c.includes("pork") || c.includes("lamb")) {
      return "bg-red-50 text-red-700 dark:bg-red-950/40 dark:text-red-300 border-red-100 dark:border-red-900/30";
    }
    return "bg-orange-50 text-orange-700 dark:bg-orange-950/40 dark:text-orange-300 border-orange-100 dark:border-orange-950/30";
  };

  return (
    <motion.div
      layout
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      transition={{ duration: 0.3 }}
      whileHover={{ y: -8 }}
      className="group bg-white dark:bg-gray-800 rounded-3xl overflow-hidden border border-gray-150 dark:border-gray-700/80 shadow-md hover:shadow-2xl transition-all duration-300 flex flex-col h-full"
      id={`recipe-card-${meal.idMeal}`}
    >
      {/* Recipe Image & Hearts */}
      <div className="relative aspect-[4/3] w-full overflow-hidden bg-gray-100 dark:bg-gray-900">
        <img
          src={meal.strMealThumb}
          alt={meal.strMeal}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 ease-out"
          loading="lazy"
          referrerPolicy="no-referrer"
        />
        
        {/* Decorative Ambient Vignette */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-transparent to-transparent pointer-events-none" />

        {/* Favorite Button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            onToggleFavorite(meal);
          }}
          className={`absolute top-4 right-4 p-2.5 rounded-full backdrop-blur-md transition-all shadow-md active:scale-90 ${
            isFavorite
              ? "bg-rose-500 text-white hover:bg-rose-600 shadow-rose-200 dark:shadow-none"
              : "bg-white/85 dark:bg-gray-900/85 text-gray-500 hover:text-rose-500 dark:text-gray-400 hover:bg-white dark:hover:bg-gray-900"
          }`}
          aria-label="Add to favorites"
          id={`fav-btn-${meal.idMeal}`}
        >
          <Heart className={`w-5 h-5 transition-transform ${isFavorite ? "fill-current scale-110" : ""}`} />
        </button>

        {/* Category & Cuisine Badge Overlay */}
        <div className="absolute bottom-3 left-4 flex flex-wrap gap-1.5 pointer-events-none">
          {meal.strCategory && (
            <span className={`px-2.5 py-1 text-[10px] md:text-xs font-bold rounded-lg uppercase tracking-wider shadow-sm border ${getCategoryStyles(meal.strCategory)}`}>
              {meal.strCategory}
            </span>
          )}
          {meal.strArea && (
            <span className="px-2.5 py-1 text-[10px] md:text-xs font-bold rounded-lg uppercase tracking-wider bg-black/60 text-white backdrop-blur-sm shadow-sm">
              {meal.strArea}
            </span>
          )}
        </div>
      </div>

      {/* Content Area */}
      <div className="p-5 flex flex-col flex-grow">
        {/* Title */}
        <h3 className="font-sans font-bold text-gray-900 dark:text-gray-100 text-base md:text-lg line-clamp-2 leading-snug mb-2 group-hover:text-orange-500 dark:group-hover:text-orange-400 transition-colors">
          {meal.strMeal}
        </h3>

        {/* Context info (if loaded) */}
        {!meal.strCategory && (
          <p className="text-xs text-gray-400 dark:text-gray-500 mb-4 h-5 flex items-center">
            Tap details to discover category & steps
          </p>
        )}

        <div className="mt-auto pt-4 flex items-center justify-between border-t border-gray-100 dark:border-gray-700/60">
          <span className="text-[10px] md:text-xs font-mono text-gray-400 dark:text-gray-500">
            ID: #{meal.idMeal}
          </span>
          
          <button
            onClick={() => onViewDetails(meal)}
            className="flex items-center gap-1 text-xs md:text-sm font-semibold text-orange-600 dark:text-orange-400 hover:text-orange-700 dark:hover:text-orange-300 group-hover:translate-x-1 transition-all"
            id={`view-details-${meal.idMeal}`}
          >
            View Details <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </motion.div>
  );
}
