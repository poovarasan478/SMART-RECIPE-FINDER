import React from "react";
import { Search, X, RotateCcw, Flame } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface SearchBarProps {
  query: string;
  setQuery: (query: string) => void;
  onSearch: (e: React.FormEvent) => void;
  isLoading: boolean;
  history: string[];
  onSelectHistory: (item: string) => void;
  onClearHistory: () => void;
  popularIngredients: string[];
}

export default function SearchBar({
  query,
  setQuery,
  onSearch,
  isLoading,
  history,
  onSelectHistory,
  onClearHistory,
  popularIngredients,
}: SearchBarProps) {
  return (
    <div className="w-full max-w-3xl mx-auto px-4" id="search-section">
      <form onSubmit={onSearch} className="relative z-10" id="search-form">
        <div className="relative flex items-center">
          <div className="absolute left-4 text-orange-500 pointer-events-none">
            <Search className="w-5 h-5" />
          </div>
          
          <input
            id="ingredient-search-input"
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search ingredients (e.g. Chicken, Tomato, Garlic, Cheese...)"
            className="w-full pl-12 pr-24 py-4 rounded-2xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100 shadow-xl focus:outline-none focus:ring-2 focus:ring-orange-500 transition-all text-base md:text-lg font-sans"
            disabled={isLoading}
          />

          <div className="absolute right-2 flex items-center gap-1.5">
            {query && (
              <button
                type="button"
                onClick={() => setQuery("")}
                className="p-1 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 transition-colors rounded-full"
                id="clear-search-button"
              >
                <X className="w-5 h-5" />
              </button>
            )}
            
            <button
              type="submit"
              disabled={isLoading || !query.trim()}
              className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-orange-500 to-rose-500 hover:from-orange-600 hover:to-rose-600 text-white font-medium text-sm md:text-base shadow-md transition-all active:scale-95 disabled:opacity-50 disabled:pointer-events-none"
              id="submit-search-button"
            >
              {isLoading ? (
                <span className="flex items-center gap-2">
                  <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                  Searching
                </span>
              ) : (
                "Search"
              )}
            </button>
          </div>
        </div>
      </form>

      {/* Popular Ingredients Section */}
      <div className="mt-4 flex flex-wrap items-center gap-2" id="popular-ingredients-container">
        <span className="text-xs font-semibold text-gray-500 dark:text-gray-400 flex items-center gap-1 mr-1 uppercase tracking-wider">
          <Flame className="w-3.5 h-3.5 text-orange-500 animate-pulse" /> Popular:
        </span>
        {popularIngredients.map((ing) => (
          <button
            key={ing}
            type="button"
            onClick={() => setQuery(ing)}
            className={`px-3 py-1 text-xs rounded-full border transition-all ${
              query.toLowerCase() === ing.toLowerCase()
                ? "bg-orange-500 border-orange-500 text-white font-medium"
                : "bg-orange-50/50 dark:bg-orange-950/20 hover:bg-orange-100 dark:hover:bg-orange-950/40 border-orange-100 dark:border-orange-900/60 text-orange-700 dark:text-orange-300"
            }`}
            id={`popular-ingredient-${ing.toLowerCase()}`}
          >
            {ing}
          </button>
        ))}
      </div>

      {/* Search History Section */}
      <AnimatePresence>
        {history.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="mt-4 p-3 bg-gray-50 dark:bg-gray-800/50 rounded-xl border border-gray-100 dark:border-gray-800/80"
            id="search-history-container"
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-medium text-gray-500 dark:text-gray-400 flex items-center gap-1">
                <RotateCcw className="w-3 h-3" /> Recent Searches
              </span>
              <button
                type="button"
                onClick={onClearHistory}
                className="text-xs text-gray-400 hover:text-red-500 transition-colors"
                id="clear-history-button"
              >
                Clear All
              </button>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {history.map((hist, index) => (
                <button
                  key={`${hist}-${index}`}
                  type="button"
                  onClick={() => onSelectHistory(hist)}
                  className="px-2.5 py-1 text-xs font-medium bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300 hover:text-orange-500 dark:hover:text-orange-400 hover:border-orange-200 dark:hover:border-orange-950 rounded-lg transition-colors cursor-pointer"
                  id={`history-${index}`}
                >
                  {hist}
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
