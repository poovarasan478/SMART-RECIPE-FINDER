import { useEffect, useState } from "react";
import { X, Youtube, ListChecks, FileText, Globe, CheckCircle2, Bookmark, Heart } from "lucide-react";
import { DetailedMeal, Meal } from "../types";
import { motion, AnimatePresence } from "motion/react";

interface RecipeDetailsProps {
  mealId: string | null;
  isOpen: boolean;
  onClose: () => void;
  favorites: Meal[];
  onToggleFavorite: (meal: Meal) => void;
}

export default function RecipeDetails({
  mealId,
  isOpen,
  onClose,
  favorites,
  onToggleFavorite,
}: RecipeDetailsProps) {
  const [meal, setMeal] = useState<DetailedMeal | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [checkedIngredients, setCheckedIngredients] = useState<Record<string, boolean>>({});

  // Fetch detailed recipe when opened
  useEffect(() => {
    if (!isOpen || !mealId) {
      setMeal(null);
      return;
    }

    const fetchDetails = async () => {
      setIsLoading(true);
      setError(null);
      setCheckedIngredients({});
      try {
        const response = await fetch(
          `https://www.themealdb.com/api/json/v1/1/lookup.php?i=${mealId}`
        );
        const data = await response.json();
        
        if (data && data.meals && data.meals.length > 0) {
          setMeal(data.meals[0] as DetailedMeal);
        } else {
          setError("Requested recipe details could not be found.");
        }
      } catch (err) {
        console.error("Error fetching recipe details:", err);
        setError("Network error. Please check your internet connection.");
      } finally {
        setIsLoading(false);
      }
    };

    fetchDetails();
  }, [isOpen, mealId]);

  // Prevent scroll when modal is active
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "unset";
    }
    return () => {
      document.body.style.overflow = "unset";
    };
  }, [isOpen]);

  // Extract ingredients & measurements
  const getIngredients = (recipe: DetailedMeal) => {
    const list: { ingredient: string; measure: string }[] = [];
    for (let i = 1; i <= 20; i++) {
      const ing = recipe[`strIngredient${i}`];
      const meas = recipe[`strMeasure${i}`];
      if (ing && ing.trim()) {
        list.push({
          ingredient: ing.trim(),
          measure: meas && meas.trim() ? meas.trim() : "To taste",
        });
      }
    }
    return list;
  };

  const isFav = meal ? favorites.some((f) => f.idMeal === meal.idMeal) : false;

  const toggleCheck = (ingName: string) => {
    setCheckedIngredients((prev) => ({
      ...prev,
      [ingName]: !prev[ingName],
    }));
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 overflow-y-auto" id="details-modal-wrapper">
          {/* Backdrop Overlay */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm"
            id="modal-backdrop"
          />

          {/* Modal Container */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            transition={{ type: "spring", duration: 0.5, bounce: 0.15 }}
            className="relative bg-white dark:bg-gray-900 rounded-3xl w-full max-w-4xl max-h-[85vh] overflow-y-auto shadow-2xl border border-gray-100 dark:border-gray-800 flex flex-col z-10"
            id="modal-content-container"
          >
            {/* Modal Header Actions */}
            <div className="sticky top-0 right-0 left-0 flex justify-between items-center p-4 bg-white/90 dark:bg-gray-900/95 backdrop-blur-md border-b border-gray-100 dark:border-gray-800 z-20">
              <span className="text-xs font-mono text-gray-500 dark:text-gray-400 font-semibold px-2 py-1 bg-gray-100 dark:bg-gray-850 rounded">
                RECIPE DETAILS
              </span>
              <div className="flex items-center gap-2">
                {meal && (
                  <button
                    onClick={() => onToggleFavorite(meal)}
                    className={`p-2 rounded-full transition-all border ${
                      isFav
                        ? "bg-rose-50 border-rose-200 text-rose-500 dark:bg-rose-950/20 dark:border-rose-950"
                        : "hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-500 border-gray-200 dark:border-gray-700"
                    }`}
                    title={isFav ? "Remove from Favorites" : "Save to Favorites"}
                    id="modal-favorite-toggle"
                  >
                    <Heart className={`w-5 h-5 ${isFav ? "fill-current" : ""}`} />
                  </button>
                )}
                <button
                  onClick={onClose}
                  className="p-2 rounded-full bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-700 text-gray-600 dark:text-gray-300 transition-colors"
                  aria-label="Close modal"
                  id="modal-close-button"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Modal Scrollable Body */}
            <div className="p-6 md:p-8" id="modal-body-scroll">
              {isLoading && (
                <div className="flex flex-col items-center justify-center py-20 gap-4" id="modal-loader">
                  <div className="w-12 h-12 border-4 border-orange-500 border-t-transparent rounded-full animate-spin"></div>
                  <p className="text-gray-500 dark:text-gray-400 font-medium">Loading recipe directions...</p>
                </div>
              )}

              {error && (
                <div className="text-center py-12 text-red-500 dark:text-red-400" id="modal-error">
                  <CheckCircle2 className="w-12 h-12 text-red-400 mx-auto mb-3 opacity-30" />
                  <p className="font-semibold">{error}</p>
                  <button
                    onClick={onClose}
                    className="mt-4 px-6 py-2 rounded-xl bg-gray-200 dark:bg-gray-800 text-gray-700 dark:text-gray-300 font-semibold"
                  >
                    Close
                  </button>
                </div>
              )}

              {meal && !isLoading && !error && (
                <div className="grid grid-cols-1 md:grid-cols-12 gap-8" id="recipe-composition-grid">
                  {/* Left Column: Image, Tags, Source */}
                  <div className="md:col-span-5 flex flex-col gap-6" id="recipe-meta-column">
                    <div className="rounded-2xl overflow-hidden aspect-[4/3] shadow-lg border border-gray-100 dark:border-gray-800">
                      <img
                        src={meal.strMealThumb}
                        alt={meal.strMeal}
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                    </div>

                    {/* Metadata Badges */}
                    <div className="bg-gray-50 dark:bg-gray-800/40 p-4 rounded-2xl border border-gray-100 dark:border-gray-800">
                      <h4 className="text-xs font-bold text-gray-400 dark:text-gray-500 uppercase tracking-wider mb-3">Classification</h4>
                      <div className="flex flex-wrap gap-2">
                        {meal.strCategory && (
                          <div className="px-3 py-1.5 rounded-xl bg-orange-50/75 text-orange-700 border border-orange-100 dark:bg-orange-950/20 dark:text-orange-300 dark:border-orange-900/40 text-xs font-semibold">
                            Category: {meal.strCategory}
                          </div>
                        )}
                        {meal.strArea && (
                          <div className="px-3 py-1.5 rounded-xl bg-rose-50/75 text-rose-700 border border-rose-100 dark:bg-rose-950/20 dark:text-rose-300 dark:border-rose-900/40 text-xs font-semibold">
                            Cuisine: {meal.strArea}
                          </div>
                        )}
                        {meal.strTags && meal.strTags.split(",").map((tag) => (
                          <div
                            key={tag}
                            className="px-2.5 py-1 rounded-lg bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-300 text-[10px] md:text-xs font-mono"
                          >
                            #{tag.trim()}
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Media & Web Links */}
                    <div className="flex flex-col gap-3">
                      {meal.strYoutube && (
                        <a
                          href={meal.strYoutube}
                          target="_blank"
                          rel="noreferrer"
                          className="flex items-center justify-center gap-2 w-full py-3 px-4 rounded-xl bg-red-600 hover:bg-red-700 text-white font-semibold text-sm transition-all shadow-md active:scale-95 text-center"
                          id="meal-youtube-link"
                        >
                          <Youtube className="w-5 h-5" /> Watch on YouTube
                        </a>
                      )}
                      
                      {meal.strSource && (
                        <a
                          href={meal.strSource}
                          target="_blank"
                          rel="noreferrer"
                          className="flex items-center justify-center gap-2 w-full py-3 px-4 rounded-xl bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-750 text-gray-800 dark:text-gray-200 font-semibold text-sm transition-all border border-gray-200 dark:border-gray-700 text-center"
                          id="meal-recipe-web-link"
                        >
                          <Globe className="w-4 h-4" /> Original Web Directions
                        </a>
                      )}
                    </div>
                  </div>

                  {/* Right Column: Ingredients & Instructions */}
                  <div className="md:col-span-7 flex flex-col gap-8" id="recipe-body-column">
                    <div>
                      <h2 className="font-display font-bold text-2xl md:text-3xl text-gray-900 dark:text-white leading-tight mb-2">
                        {meal.strMeal}
                      </h2>
                      <div className="w-16 h-1.5 bg-gradient-to-r from-orange-500 to-rose-500 rounded-full" />
                    </div>

                    {/* Ingredients Checklist */}
                    <div>
                      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2 mb-4">
                        <ListChecks className="w-5 h-5 text-orange-500" />
                        Ingredients & Portions
                        <span className="text-xs font-normal text-gray-400 dark:text-gray-500">
                          (Check off when ready)
                        </span>
                      </h3>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 bg-gray-50 dark:bg-gray-800/30 p-5 rounded-2xl border border-gray-150 dark:border-gray-800">
                        {getIngredients(meal).map(({ ingredient, measure }, index) => {
                          const stateKey = `${ingredient}-${index}`;
                          const isChecked = !!checkedIngredients[stateKey];
                          return (
                            <div
                              key={stateKey}
                              onClick={() => toggleCheck(stateKey)}
                              className={`flex items-start gap-2.5 p-2 rounded-xl transition-all cursor-pointer select-none ${
                                isChecked
                                  ? "bg-orange-50/50 dark:bg-orange-950/10 text-gray-400 line-through decoration-gray-300 dark:decoration-gray-700"
                                  : "hover:bg-white dark:hover:bg-gray-800/80 text-gray-700 dark:text-gray-300"
                              }`}
                            >
                              <div className="mt-0.5 min-w-4">
                                <input
                                  type="checkbox"
                                  checked={isChecked}
                                  onChange={() => {}} // toggled on container tap
                                  className="rounded border-gray-300 dark:border-gray-700 text-orange-500 focus:ring-orange-500 h-4 w-4 pointer-events-none"
                                />
                              </div>
                              <div className="flex-1 text-xs sm:text-sm">
                                <span className={isChecked ? "text-gray-400" : "font-semibold text-gray-850 dark:text-gray-250"}>
                                  {ingredient}
                                </span>
                                <span className="block text-[11px] text-gray-400 dark:text-gray-500">
                                  {measure}
                                </span>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>

                    {/* Instructions Section */}
                    <div>
                      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2 mb-4">
                        <FileText className="w-5 h-5 text-orange-500" />
                        Method & Cook Steps
                      </h3>
                      <div className="whitespace-pre-line text-xs sm:text-sm leading-relaxed text-gray-750 dark:text-gray-300 bg-gray-50 dark:bg-gray-800/10 p-5 sm:p-6 rounded-2xl border border-gray-150 dark:border-gray-850">
                        {meal.strInstructions ? (
                          // Split into sentences or paragraphs for readable rendering
                          meal.strInstructions
                            .split("\r\n")
                            .filter((para) => para.trim().length > 0)
                            .map((para, pIdx) => (
                              <p key={pIdx} className="mb-4 last:mb-0">
                                {para}
                              </p>
                            ))
                        ) : (
                          <p className="text-gray-400 dark:text-gray-500 italic">No instructions provided.</p>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
